var Cryptr = require('cryptr');
var express=require("express");
var connection = require('./../config');
// cryptr = new Cryptr('myTotalySecretKey');
 
module.exports.register=function(req,res){
    var today = new Date();
    //console.log(req.body.password);
    var encryptedString = cryptr.encrypt(req.body.password);
    var users={
        "name":req.body.name,
        "college":req.body.college,
        "department":req.body.department,
        "semester":req.body.semester,
        "email":req.body.email,
        "password":encryptedString,
        "created at":today,
        "updated at":today
    }
    connection.query('INSERT INTO User SET ?',users, function (error, results, fields) {
      if (error) {
        console.log(error);
        res.json({
            status:false,
            message:'there are some error with query'
        })
      }else{
          /*res.json({
            status:true,
            data:results,
            message:'user registered sucessfully'*/
            res.redirect('/userlogin');
        
      }
    });
}